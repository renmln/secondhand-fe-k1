import './App.css';
import { Login } from './component';
import { LandingPage } from './component';

function App() {
  return (
    <Login />
    // <LandingPage/>
  )
}

export default App;